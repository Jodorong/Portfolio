import React from 'react'

const Site = () => {
  return (
    <div>Site</div>
  )
}

export default Site;