import React from 'react'

const Skill = () => {
  return (
    <div>Skill</div>
  )
}

export default Skill;